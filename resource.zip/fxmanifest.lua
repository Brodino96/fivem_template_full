fx_version "cerulean"
game "gta5"

author "Brodino"
description ""
version "0.1"

server_script "dist/server.js"
client_script "dist/client.js"

files {
    "config.json",
    "locales/**",
    "dist/ui/index.html",
    "dist/ui/assets/**"
}